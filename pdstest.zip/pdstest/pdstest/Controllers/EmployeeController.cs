﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using pdstest.Models;
using pdstest.BLL;
using Microsoft.Extensions.Configuration;

namespace pdstest.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IConfiguration configuration;
        public EmployeeController(IConfiguration config) {
            this.configuration = config;
        
        }
        BLLogic logic = new BLLogic();

        [HttpGet("UserTypes")]

        public IActionResult GetUserTypes()
        
        {
            APIResult result = new APIResult();
            try 
            {
                
                result = logic.GetuserTypes();

            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = false;

            }
            return new CustomResult(result);

        }

        [HttpPost]
        [Route("CreateEmployee")]
        public IActionResult CreateEmployee(RegisterEmployee obj)
        {
            APIResult result = new APIResult();
            try
            {
                if (!(string.IsNullOrEmpty(obj.FirstName)) || !(string.IsNullOrEmpty(obj.UserType)))
                {


                }
                else
                {


                }
            }
            catch (Exception e)
            {
                result.Message = e.Message;
                result.Status = false;
            
            }
            return new CustomResult(result);

        }

    }
}
