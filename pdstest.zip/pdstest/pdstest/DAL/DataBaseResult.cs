﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace pdstest.DAL
{
    public class DataBaseResult
    {
        public bool Status { get; set; }
        public string Message { get; set; }
        public int Id { get; set; }

        public string EmployeeName { get; set; }
        public DataSet ds { get; set; }

        public string CommandType { get; set; }
    }
}
